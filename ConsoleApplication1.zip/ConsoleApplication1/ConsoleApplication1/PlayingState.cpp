#include "PlayingState.h"


#include "State.h"
#include "StateMachine.h"
class StateMachine;

#include "MoreInfo.h"
#include "WinMenuState.h"
#include "LoseMenuState.h"

PlayingState::PlayingState(StateMachine& machine, sf::RenderWindow& window, bool replace)
	: State{ machine, window, replace }, ufoScore(0) {
	//player info
	player.setPlayerPos(sf::Vector2<float>(screenWidth / 2, groundHeight));
	playerVector.push_back(&player);
	Points.setString("Score: " + std::to_string(playerScore + ufoScore));

	

	//invader info
	made_enemies(3, 5);
	
	gameFont.loadFromFile(pixelFont);
	Points.setFont(gameFont);
	Points.setFillColor(sf::Color(255, 255, 0));
	Points.setCharacterSize(20);
	Points.setPosition(800, 0);
	
	//shoeld info
	shieldVector.push_back(&shield[0]);
	shieldVector.push_back(&shield[1]);
	shieldVector.push_back(&shield[2]);

	shield[0].setShieldPos(sf::Vector2<float>(screenWidth / 2 + 000, screenHeight - 300));
	shield[1].setShieldPos(sf::Vector2<float>(screenWidth / 2 - 300, screenHeight - 300));
	shield[2].setShieldPos(sf::Vector2<float>(screenWidth / 2 + 300, screenHeight - 300));

	//ufo info
	ufoVector.push_back(&ufo);
	ufo.setUFOPos(sf::Vector2<float>(screenWidth + 40, screenHeight * 0 + 100));

	//sound info
	playSound.setMusic("C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/INGAMECUTRIGHT.wav", 20, true);
}
PlayingState::~PlayingState(){
	playSound.stopMusic();
	playSound.stopSound();
}




void PlayingState::handleKeyboardInputs(sf::Keyboard::Key key, bool isPressed) {

	if (key == sf::Keyboard::A) { isMovingLeft = isPressed; }
	if (key == sf::Keyboard::D) { isMovingRight = isPressed; }
	if (key == sf::Keyboard::Space) { isBulletFiring = isPressed; }
	if (key == sf::Keyboard::Escape) {
		machine.run(machine.buildState<MainMenuState>(machine, window, true));
	}
}
void PlayingState::made_enemies(int rzedy, int kolumny)
{//invader spawn
	for (int i = 0; i < rzedy*kolumny; i++) {
		invaderVector.push_back(&invader[i]);
	}

	for (int i = 0; i < rzedy; i++) {
		for (int j = 0; j < kolumny; j++) {
			invader[j + i * kolumny].setInvaderPos(sf::Vector2<float>(screenWidth - j * 80, 200 + i * 50));
		}
	}
}
void PlayingState::updateEvents() {
	while (window.pollEvent(sfEvent)) {
		switch (sfEvent.type) {
		case sf::Event::Closed:
			machine.quit();
			break;

		case sf::Event::KeyPressed:
			handleKeyboardInputs(sfEvent.key.code, true);
			break;

		case sf::Event::KeyReleased:
			handleKeyboardInputs(sfEvent.key.code, false);
			break;

		}
	}
}

void PlayingState::update() {

	//fpsCounter.updateCounter();
	

	//player logic
	sf::Vector2<float> playerMovement(0.f, 0.f);
	if (isMovingLeft) {
		playerMovement.x -= playerSpeed;
	}
	if (isMovingRight) {
		playerMovement.x += playerSpeed;
	}
	player.moveTo(playerMovement);

	//pBullet logic
	sf::Vector2<float> pBulletMovement(0.f, 0.f);
	pBulletMovement.y -= bulletSpeed;

	if (isBulletFiring) {
		if (pBulletCount <= 1) {
			switch (pBulletCount) {
			case 0:
				pBullet.setBulletPos(sf::Vector2<float>(player.getX(), player.getY()));
				playSound.setSound("C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/SHOOTCUTRIGHT.wav", 35, false);
				break;
			}
			pBulletCount++;
			isBulletFiring = false;

		}
		if (pBulletCount > 1) {
			isBulletFiring = false;
			pBulletTimer = pBulletClock.getElapsedTime().asSeconds();
			if (pBulletTimer >= 1.500) {
				pBulletCount = 0;
				pBulletClock.restart();
			}
		}
	}


	pBullet.moveTo(pBulletMovement);


	//invaders logic

	sf::Vector2<float> invaderMovement(0.f, 0.f);
	invaderTimer = invaderClock.getElapsedTime().asSeconds();
	invaderDownTimer = invaderDownClock.getElapsedTime().asSeconds();

	// left/right
	if (invaderTimer > 0) { isInvaderLeft = true; }
	if (invaderTimer > 2.8) { isInvaderLeft = false; isInvaderRight = true; }
	if (invaderTimer > 5.6) { isInvaderRight = false; invaderClock.restart().asSeconds(); }

	//down 
	if (invaderDownTimer >= 20) { isInvaderDown = true; }
	if (invaderDownTimer >= 20.3) { isInvaderDown = false; invaderDownClock.restart().asSeconds(); }

	//moves
	if (isInvaderLeft) { invaderMovement.x -= invaderSpeed; }//left
	if (isInvaderRight) { invaderMovement.x += invaderSpeed; }//right
	if (isInvaderDown) { invaderMovement.y += invaderSpeed; }//down

	//collision n movements
	for (int x = 0; x < invaderVector.size(); x++) {
		invaderVector[x]->moveTo(invaderMovement);

		if (pBullet.collisionWithInvader(invaderVector[x])) {
			invaderVector[x]->setInvaderPos({ 100000, 100000 });
			pBullet.setBulletPos({ 2000, 1000 });
			playSound.setSound("C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/POINTSCUTRIGHT.wav", 35, false);
			pBulletCount = 0;
			pBulletClock.restart();
			playerScore++;
			Points.setString("Score: " + std::to_string(playerScore));
			std::cout << playerScore << std::endl;
		}
	}

	//shooting
	sf::Vector2<float> iBulletMovement(0.f, 0.f);
	iBulletMovement.y += bulletSpeed;

	iBulletTimer = iBulletClock.getElapsedTime().asSeconds();
	
	if (iBulletTimer > 1.000) {
		shooter = random.getInt(1, 15);
		if (shooter >= 1 && shooter <= 15) {
			int invaderIndex = shooter - 1;
			if (invader[invaderIndex].getX() >= screenWidth * 0 && invader[invaderIndex].getX() <= screenWidth) {
				iBulletTimer2 = iBulletClock2.getElapsedTime().asSeconds();
				if (iBulletTimer2 > 0.000) {
					iBullet.setBulletPos(sf::Vector2<float>(invader[invaderIndex].getX(), invader[invaderIndex].getY()));
					if (iBulletTimer > 2.000) {
						iBulletClock.restart().asSeconds();
						iBulletClock2.restart().asSeconds();
					}
				}
			}
		}
	}

	iBullet.moveTo(iBulletMovement);

	for (int x = 0; x < playerVector.size(); x++) {
		if (iBullet.collisionWithPlayer(playerVector[x])) {
			iBullet.setBulletPos(sf::Vector2<float>(10000, 10000));
			playerLives--;

		}
	}

	//shield logic
	for (int x = 0; x < shieldVector.size(); x++) {
		//cpllision with player bullets

		if (pBullet.collisionWithShield(shieldVector[x])) {
			shieldVector[x]->shieldProtection(1);
			pBullet.setBulletPos(sf::Vector2 <float>(10000, 10000));
			pBulletCount = 0;
			pBulletClock.restart().asSeconds();

			//checking for shield damage
			if (shieldVector[x]->shieldProtectionNum() <= 0) { shieldVector[x]->setShieldPos(sf::Vector2<float>(100000, 10000)); }
		}

		//collision with invader bullets
		if (iBullet.collisionWithShield(shieldVector[x])) {
			shieldVector[x]->shieldProtection(1);
			iBullet.setBulletPos(sf::Vector2<float>(10000, 10000));

			//checking for shield damage
			if (shieldVector[x]->shieldProtectionNum() <= 0) { shieldVector[x]->setShieldPos(sf::Vector2<float>(100000, 10000)); }
		}
	}

	//ufo logic
	sf::Vector2<float> ufoMovement(0.f, 0.f);

	ufoTimer = ufoClock.getElapsedTime().asSeconds();
	if (ufoTimer >= 15.000 && ufoTimer <= 19.000) { ufoMovement.x -= ufoSpeed; }
	if (ufoTimer >= 30.000 && ufoTimer <= 34.000) { ufoMovement.x += ufoSpeed;}
	if (ufoTimer >= 35.000) { ufoClock.restart().asSeconds(); }
	ufo.moveTo(ufoMovement);

	//ufo collision
	for (int x = 0; x < ufoVector.size(); x++) {
		if (pBullet.collisionWithUFO(ufoVector[x])) {
			ufoVector[x]->setUFOPos(sf::Vector2<float>(100000, 100000));
			pBullet.setBulletPos(sf::Vector2<float>(100000, 10000));
			pBulletCount = 0;
			pBulletClock.restart().asSeconds();
			ufoScore += 10; // ����������� ������� ����� �� 10 ��� ��������� � UFO
			
		}
	}


	//win or lose 
	if (playerScore >= (enemyCount + ufoScore)) { machine.run(machine.buildState<WinMenuState>(machine, window, true)); }
	if (playerLives <= 0) {
		deathTimer = deathClock.getElapsedTime().asSeconds();
		playSound.setSound("C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/SHOOTCUTRIGHT.wav", 35, false);
		if (deathTimer >= 2.000) { machine.run(machine.buildState<LoseMenuState>(machine, window, true)); }
	}
}






void PlayingState::render() {
	window.clear();

	//Render items
	//fpsCounter.renderTo(window);
	player.renderTo(window);
	pBullet.renderTo(window);
	iBullet.renderTo(window);
	ufo.renderTo(window);
	window.draw(Points);
	for (int x = 0; x < invaderVector.size(); x++) { invaderVector[x]->renderTo(window); }
	for (int x = 0; x < shieldVector.size(); x++) { shieldVector[x]->renderTo(window); }

	window.display();
}

	