#ifndef PLAYSOUND_H
#define PLAYSOUND_H

#include "SFML/Audio.hpp"

class PlaySound
{
public:
	PlaySound() = default;
	
	void setSound(std::string SoundName, unsigned int volume, bool loopSound);
	void setMusic(std::string musicName, unsigned int volume, bool loopMusic);
	void stopSound();
	void stopMusic();


private:
	sf::SoundBuffer soundBuffer;
	sf::Sound sound;

	sf::Music music;
};

#endif // !PLAYSOUND_H