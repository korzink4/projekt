#ifndef MAINMENUSTATE_H
#define MAINMENUSTATE_H

#include "SFML/Graphics.hpp"
#include "SFML/System.hpp"
#include "SFML/Window.hpp"
#include "SFML/Network.hpp"
#include "SFML/Audio.hpp"
#include "SFML/System/Vector2.hpp"


#include "State.h"
class StateMachine;

#include "FPSCounter.h"
#include "Button.h"
#include "Text.h"

#include "MoreInfo.h"

class MainMenuState : public State {
public:
	MainMenuState(StateMachine& machine, sf::RenderWindow& window, bool replace = true);

	~MainMenuState();

	void updateEvents();
	void update();
	void render();

private:
	FPSCounter fpsCounter;
	Button* startGameButton;
	Button* quitGameButton;
	Text* titleText;

	std::string pixelFont = "C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/pixelFont.ttf";

	sf::Event sfEvent;
};
#endif