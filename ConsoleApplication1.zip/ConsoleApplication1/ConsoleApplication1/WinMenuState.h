#ifndef WINMENUSTATE_H
#define WINMENUSTATE_H

#include "SFML/Graphics.hpp"
#include "Text.h"
#include"Button.h"
#include "State.h"
#include "StateMachine.h"

class StateMachine;

class WinMenuState : public State {
public:
	WinMenuState(StateMachine& machine, sf::RenderWindow& window, bool replace = true);
	~WinMenuState();

	void updateEvents();
	void update();
	void render();

private:
	Text* winText;
	Button* quitGameButton;
	Button* mainMenuButton;
	
	std::string pixelFont = "C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/pixelFont.ttf";

	sf::Event sfEvent;
};


#endif // !WINMENUSTATE_H