#ifndef LOSEMENUSTATE_H
#define LOSEMENUSTATE_H

#include "SFML/Graphics.hpp"
#include "Text.h"
#include"Button.h"
#include "State.h"
#include "StateMachine.h"

class StateMachine;

class LoseMenuState : public State {
public:
	LoseMenuState(StateMachine& machine, sf::RenderWindow& window, bool replace = true);
	~LoseMenuState();

	void updateEvents();
	void update();
	void render();

private:
	
	Text* loseText;
	Button* quitGameButton;
	Button* mainMenuButton;

	
	std::string pixelFont = "C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/pixelFont.ttf";

	sf::Event sfEvent;
};


#endif 