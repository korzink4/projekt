﻿#include "Game.h"
#include "SFML/Graphics.hpp" 

int main() {
    Game game;
    game.run();
}