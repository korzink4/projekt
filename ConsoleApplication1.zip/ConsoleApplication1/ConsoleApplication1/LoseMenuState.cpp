#include "LoseMenuState.h"

#include "MoreInfo.h"
#include "State.h"
#include "StateMachine.h"
#include "MainMenuState.h"
class StateMachine;

LoseMenuState::LoseMenuState(StateMachine& machine, sf::RenderWindow& window, bool replace)
	:State{ machine,window,replace }
{
	
	this->loseText = new Text(screenWidth / 2, screenHeight / 3, 60, pixelFont, "You Lose!", sf::Color(0, 139, 139));
	
	this->mainMenuButton = new Button(screenWidth / 2, screenHeight / 2, 150, 50, 20, pixelFont, "Main Menu", sf::Color(128, 128, 128), sf::Color(192, 192, 192),
		sf::Color(0, 0, 128), sf::Color(0, 0, 0), sf::Color(0, 2, 255));
	this->quitGameButton = new Button(screenWidth / 2, screenHeight / 2 + 100, 150, 50, 20, pixelFont, "Quit Game", sf::Color(128, 128, 128), sf::Color(192, 192, 192),
		sf::Color(0, 0, 128), sf::Color(0, 0, 0), sf::Color(0, 2, 255));
}

LoseMenuState::~LoseMenuState()
{
	delete this->loseText;
	delete this->mainMenuButton;
	delete this->quitGameButton;
}

void LoseMenuState::updateEvents()
{
	sf::Vector2<int> mousePos = sf::Mouse::getPosition(window);
	this->mainMenuButton->update(sf::Vector2<float>(mousePos));
	this->quitGameButton->update(sf::Vector2<float>(mousePos));

	while (window.pollEvent(sfEvent)) {
		switch (sfEvent.type) {
		case sf::Event::Closed:
			machine.quit();
			break;

		case sf::Event::MouseButtonPressed:
			if (this->mainMenuButton->isPressed() == true) { machine.run(machine.buildState<MainMenuState>(machine, window, true)); }
			if (this->quitGameButton->isPressed() == true) { machine.quit(); }
		}
	}
}

void LoseMenuState::update()
{
}

void LoseMenuState::render()
{
	window.clear();

	this->quitGameButton->renderTo(window);
	this->mainMenuButton->renderTo(window);
	this->loseText->renderTo(window);

	window.display();
}
