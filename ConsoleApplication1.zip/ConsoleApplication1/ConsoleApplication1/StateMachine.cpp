#include "StateMachine.h"
#include <memory>

StateMachine::StateMachine()
	: stateResume{ false }
	, stateRunning{ false } {
}

void StateMachine::run(std::unique_ptr<State> state){
	stateRunning = true;
	states.push(std::move(state));
	
}
void StateMachine::nextState() {
		if (stateRunning) {
			/*if (!states.empty()) { states.pop(); }*/
			if (!states.empty()) {
				std::unique_ptr<State> temp = states.top()->nextState();

				if (temp != nullptr) {
					if (temp->isReplacing()) { states.pop(); }
					states.push(std::move(temp));
				}
			}
			stateResume = false;
		}
		
}

void StateMachine::lastState() {
		stateResume = true;
}

void StateMachine::update() {
	if (!states.empty()) {
		states.top()->update();
	}
}

void StateMachine::render() {
	if (!states.empty()) {
		states.top()->render();
	}
}

bool StateMachine::running() {
	return true;
}


void StateMachine::quit() {
	stateRunning = false;
}

void StateMachine::updateEvents() {
	if (!states.empty()) {
		states.top()->updateEvents();
	}
}
