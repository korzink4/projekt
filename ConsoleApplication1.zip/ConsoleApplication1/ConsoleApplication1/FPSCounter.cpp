#include "FPSCounter.h"

FPSCounter::FPSCounter() {
	gameFont.loadFromFile(pixelFont);
	framerateCounter.setFont(gameFont);
	framerateCounter.setFillColor(sf::Color(255, 255, 0));
	framerateCounter.setCharacterSize(20);
	framerateCounter.setPosition(0, 0);
}

void FPSCounter::renderTo(sf::RenderWindow& window) {
	window.draw(framerateCounter);

}

void FPSCounter::updateCounter() {
	fpsTimer = fpsClock.getElapsedTime();

	ssFPS.str("");
	ssFPS << "fps:" << 1.0f / fpsTimer.asSeconds();
	framerateCounter.setString(ssFPS.str());

	fpsClock.restart();
}