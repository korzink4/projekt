#include "PlayerBullet.h"


PlayerBullet::PlayerBullet() {
	texture.loadFromFile("C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/SIBullet.png");
	sf::Vector2<unsigned> bulletChar = texture.getSize();
	bulletChar.x /= 1;
	bulletChar.y /= 1;
	bullet.setTexture(texture);
	bullet.setTextureRect(sf::IntRect(bulletChar.x * 0, bulletChar.y * 0, bulletChar.x, bulletChar.y));
	bullet.setOrigin(bulletChar.x / 2, bulletChar.y / 2);
	bullet.scale(1 * 1.5, 1 * 1.5);
}

void PlayerBullet::renderTo(sf::RenderWindow& window) {
	window.draw(bullet);
}

void PlayerBullet::setBulletPos(sf::Vector2<float> newPos) {
	bullet.setPosition(newPos);
}

void PlayerBullet::moveTo(sf::Vector2<float> distance) {
	bullet.move(distance);

}

int PlayerBullet::getX() {
	return bullet.getPosition().x;
}
int PlayerBullet::getY() {
	return bullet.getPosition().y;
}

sf::FloatRect PlayerBullet::getGlobalBounds() {
	return bullet.getGlobalBounds();
}

bool PlayerBullet::collisionWithInvader(Invader* invader) {
	if (getGlobalBounds().intersects(invader->getGlobalBounds())) {
		return true;
	}
	return false;
}

bool PlayerBullet::collisionWithShield(Shield* shield)
{
	if (getGlobalBounds().intersects(shield->getGlobalBounds())) {
		return true;
	}
	return false;
}

bool PlayerBullet::collisionWithUFO(UFO* ufo)
{
	if (getGlobalBounds().intersects(ufo->getGlobalBounds())) {
		
		return true;
	}
	return false;
}
