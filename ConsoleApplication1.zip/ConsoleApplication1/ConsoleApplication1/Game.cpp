#include "Game.h"
#include "MoreInfo.h"
void Game::run() {
	window.create(sf::VideoMode(screenWidth, screenHeight), "Space Invaders 196692");
	window.setPosition({ window.getPosition().x, window.getPosition().y - 40 });
	window.setFramerateLimit(120);
	
	machine.run(StateMachine::buildState<MainMenuState>(machine, window, true));
	
	while (window.isOpen())
	{
		//machine.nextState();
		machine.updateEvents();
		machine.update();
		machine.render();
	}


}