#ifndef PLAYINGSTATE_H
#define PLAYINGSTATE_H

#include "SFML/Audio.hpp"
#include "SFML/Graphics.hpp"
#include "SFML/System.hpp"
#include "SFML/Window.hpp"
#include "SFML/Network.hpp"
#include "SFML/System/Vector2.hpp"

#include "Player.h"
#include "Invader.h"
#include "Player.h"
#include "PlayerBullet.h"
#include "InvaderBullet.h"
#include "Shield.h"
#include "UFO.h"
#include "Button.h"
#include "PlaySound.h"
#include "State.h"
#include "MainMenuState.h"
#include "Random.h"

class StateMachine;


class PlayingState :
    public State
{
	public:
		PlayingState(StateMachine& machine, sf::RenderWindow& window, bool replace = true);
        ~PlayingState();

		void handleKeyboardInputs(sf::Keyboard::Key key, bool isPressed);
		void made_enemies(int rzedy,int kolumny);
		void updateEvents();
		void update();
		void render();

private:
	//vectors
	std::vector<Player*> playerVector;
	std::vector<Invader*> invaderVector;
	std::vector<Shield*> shieldVector;
	std::vector<UFO*> ufoVector;

	//class objects
	Random<> random;
	//FPSCounter fpsCounter;
	PlaySound playSound;
	Player player;
	Invader  invader[15];
	PlayerBullet pBullet;
	InvaderBullet iBullet;
	Shield shield[3];
	UFO ufo;
	std::string pixelFont = "C:/Users/zutto/Desktop/ConsoleApplication1/ConsoleApplication1/pixelFont.ttf";
	sf::Font gameFont;
	sf::Text Points;
	//vars & bools
	const int playerSpeed     = 2;
	const float invaderSpeed  = 2;
	const float bulletSpeed   = 9;
	const float ufoSpeed      = 3;
    unsigned int pBulletCount = 0;

	int shooter          = 0;
	int playerLives      = 3;
	int shieldProtection = 5;
	int playerScore      = 0;
	int enemyCount       = 15;
	int ufoScore;

	bool isMovingLeft   = false;
	bool isMovingRight  = false;
	bool isBulletFiring = false;

	bool isInvaderLeft  = false;
	bool isInvaderRight = false;
	bool isInvaderDown  = false;
	
	sf::Event sfEvent;
	sf::Clock invaderClock, invaderDownClock, pBulletClock, iBulletClock, iBulletClock2, ufoClock, deathClock;
	float invaderTimer, invaderDownTimer, pBulletTimer, iBulletTimer, iBulletTimer2, ufoTimer, deathTimer;

};

#endif